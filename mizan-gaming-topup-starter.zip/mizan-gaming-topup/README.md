# Mizan Gaming — Top-Up MVP

This is a starter project for a Free Fire top-up **order submission and manual payment review** website. It is not connected to Garena or a diamond supplier, so it does not deliver diamonds automatically.

## Included
- Responsive top-up page and package list
- UID + package + payment method + transaction reference order submission
- Random public order code for tracking
- Admin login using a bcrypt password hash
- Admin order list and status updates
- PostgreSQL storage for orders and sessions
- Helmet security headers, login rate limiting, parameterized SQL queries
- No collection of game passwords, payment PINs, or OTPs

## Requirements
- Node.js 20+
- PostgreSQL database
- A hosting provider that supports Node.js and PostgreSQL

## Local setup
1. Install Node.js 20+ and PostgreSQL.
2. Copy `.env.example` to `.env`.
3. Create a PostgreSQL database and set `DATABASE_URL`.
4. Generate an admin password hash:
   ```bash
   node -e "console.log(require('bcryptjs').hashSync('choose-a-long-unique-password', 12))"
   ```
   Put the result in `ADMIN_PASSWORD_HASH`. Do not put a plain password in this variable.
5. Set a long random `SESSION_SECRET`.
6. Run:
   ```bash
   npm install
   npm start
   ```
7. Open `http://localhost:3000`.

The app creates the tables on startup. Keep `.env` private and never upload it to GitHub.

## Low-cost deployment outline
1. Create a managed PostgreSQL database with a provider that offers a free/trial tier.
2. Create a Node web service (for example, Render) and connect this repository.
3. Set `DATABASE_URL`, `PGSSL=true`, `SESSION_SECRET`, `ADMIN_USERNAME`, and `ADMIN_PASSWORD_HASH` in the host's environment settings.
4. Use HTTPS and test a complete test order before sharing the site.
5. Free hosting/database plans can sleep, expire, or have limits; check current provider terms and backups before launch.

## Important before taking real orders
- Replace the demo prices in `server.js` with confirmed supplier prices and your own clearly stated service fee.
- Secure a lawful, authorized supply channel for top-ups. Do not claim a diamond delivery is automatic until you have a verified authorized integration or a reliable manual fulfilment process.
- Use a merchant/business payment option that you are eligible for. Confirm bKash/Nagad merchant terms before accepting customer payments.
- Display your real payment recipient details only after you control the account and have checked the provider's rules. This project intentionally uses placeholders.
- Admin should independently verify the transaction in the official payment account. A transaction reference typed by a customer is not proof of payment.
- Add privacy policy, terms, refund policy, support contact, and a clear expected delivery window.
- Add CSRF protection and an email/phone verification flow before production use. This MVP is a starter, not a completed security audit.
- Back up the database and restrict access to production credentials.

## Admin
Open `/admin` and sign in using `ADMIN_USERNAME` and the password corresponding to `ADMIN_PASSWORD_HASH`.

Order status values: `pending`, `verified`, `processing`, `completed`, `rejected`, `refunded`.
Mark an order `completed` only after fulfilment is actually confirmed.
