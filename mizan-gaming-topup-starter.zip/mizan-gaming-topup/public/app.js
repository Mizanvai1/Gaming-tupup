const $ = (id) => document.getElementById(id);
$("year").textContent = new Date().getFullYear();

$("orderForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const button = event.currentTarget.querySelector("button[type=submit]");
  const message = $("orderMessage");
  button.disabled = true;
  message.className = "message";
  message.textContent = "অর্ডার জমা হচ্ছে…";
  const body = {
    playerUid: $("playerUid").value.trim(),
    packageId: new FormData(event.currentTarget).get("packageId"),
    paymentMethod: $("paymentMethod").value,
    transactionRef: $("transactionRef").value.trim(),
    customerNote: $("customerNote").value.trim()
  };
  try {
    const res = await fetch("/api/orders", { method: "POST", headers: {"Content-Type":"application/json"}, body: JSON.stringify(body) });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "অর্ডার জমা হয়নি।");
    message.className = "message success";
    message.innerHTML = "";
    const p = document.createElement("p");
    p.textContent = data.message;
    const code = document.createElement("strong");
    code.textContent = "আপনার অর্ডার নম্বর: " + data.orderCode;
    const save = document.createElement("p");
    save.textContent = "এই নম্বরটি সংরক্ষণ করুন।";
    message.append(p, code, save);
    $("orderCode").value = data.orderCode;
    event.currentTarget.reset();
  } catch (err) {
    message.className = "message error";
    message.textContent = err.message;
  } finally {
    button.disabled = false;
  }
});

$("trackForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const msg = $("trackMessage");
  msg.className = "message";
  msg.textContent = "খোঁজা হচ্ছে…";
  try {
    const code = encodeURIComponent($("orderCode").value.trim());
    const res = await fetch("/api/track/" + code);
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "অর্ডার পাওয়া যায়নি।");
    msg.className = "message success";
    msg.textContent = `অর্ডার ${data.order_code} · ${data.diamonds} ডায়মন্ড · ৳${data.amount_bdt} · স্ট্যাটাস: ${data.status}`;
  } catch (err) {
    msg.className = "message error";
    msg.textContent = err.message;
  }
});
