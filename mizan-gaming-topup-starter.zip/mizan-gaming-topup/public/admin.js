const $ = (id) => document.getElementById(id);
const statusOptions = ["pending","verified","processing","completed","rejected","refunded"];
const pretty = {pending:"Pending",verified:"Verified",processing:"Processing",completed:"Completed",rejected:"Rejected",refunded:"Refunded"};
async function api(url, options={}) {
  const res = await fetch(url, { headers: {"Content-Type":"application/json"}, ...options });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || "Request failed");
  return data;
}
function showLogin() { $("loginPanel").hidden = false; $("dashboard").hidden = true; }
function showDashboard() { $("loginPanel").hidden = true; $("dashboard").hidden = false; loadOrders(); }
async function checkSession() {
  try { const d = await api("/api/admin/me"); d.authenticated ? showDashboard() : showLogin(); }
  catch (_) { showLogin(); }
}
$("loginForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  $("loginMessage").textContent = "লগইন হচ্ছে…";
  try {
    await api("/api/admin/login", {method:"POST", body:JSON.stringify({username:$("username").value.trim(),password:$("password").value})});
    $("loginMessage").textContent = "";
    $("password").value = "";
    showDashboard();
  } catch (err) { $("loginMessage").className="message error"; $("loginMessage").textContent=err.message; }
});
$("logoutButton").addEventListener("click", async () => {
  try { await api("/api/admin/logout", {method:"POST",body:"{}"}); } finally { showLogin(); }
});
$("refreshButton").addEventListener("click", loadOrders);
$("statusFilter").addEventListener("change", loadOrders);
let searchTimer;
$("search").addEventListener("input", () => { clearTimeout(searchTimer); searchTimer=setTimeout(loadOrders, 250); });

async function updateOrder(code, card) {
  const status = card.querySelector("select").value;
  const adminNote = card.querySelector("textarea").value.trim();
  const btn = card.querySelector("button");
  btn.disabled = true;
  try {
    await api("/api/admin/orders/" + encodeURIComponent(code), {method:"PATCH", body:JSON.stringify({status,adminNote})});
    await loadOrders();
  } catch (err) { alert(err.message); btn.disabled = false; }
}
function make(tag, cls, text) {
  const el = document.createElement(tag);
  if (cls) el.className = cls;
  if (text !== undefined) el.textContent = text;
  return el;
}
async function loadOrders() {
  const wrap = $("orders");
  if ($("dashboard").hidden) return;
  $("ordersMessage").textContent = "অর্ডার লোড হচ্ছে…";
  try {
    const qs = new URLSearchParams();
    if ($("statusFilter").value) qs.set("status", $("statusFilter").value);
    if ($("search").value.trim()) qs.set("search", $("search").value.trim());
    const rows = await api("/api/admin/orders?" + qs.toString());
    wrap.replaceChildren();
    $("ordersMessage").textContent = rows.length ? `${rows.length}টি অর্ডার দেখানো হচ্ছে (সর্বোচ্চ ২০০)।` : "কোনো অর্ডার পাওয়া যায়নি।";
    for (const order of rows) {
      const card = make("article","order-card");
      const head = make("div","order-head");
      head.append(make("strong","",order.order_code), make("span","status "+order.status,pretty[order.status] || order.status));
      const details = make("p","order-details",`UID: ${order.player_uid} · ${order.diamonds} diamonds · ৳${order.amount_bdt}`);
      const pay = make("p","order-details",`Payment: ${order.payment_method.toUpperCase()} · Transaction ref: ${order.transaction_ref}`);
      const date = make("p","hint",`তৈরি: ${new Date(order.created_at).toLocaleString()}`);
      const label = make("label","","স্ট্যাটাস");
      const select = document.createElement("select");
      for (const s of statusOptions) {
        const opt = document.createElement("option"); opt.value=s; opt.textContent=pretty[s]; if(s===order.status) opt.selected=true; select.append(opt);
      }
      label.append(select);
      const noteLabel = make("label","","Admin note");
      const note = document.createElement("textarea"); note.maxLength=250; note.rows=2; note.placeholder="যাচাই/ডেলিভারির নোট"; note.value=order.admin_note || ""; noteLabel.append(note);
      const btn = make("button","primary","স্ট্যাটাস সংরক্ষণ");
      btn.addEventListener("click", () => updateOrder(order.order_code,card));
      card.append(head,details,pay,date,label,noteLabel,btn);
      if(order.customer_note) card.append(make("p","hint","Customer note: "+order.customer_note));
      wrap.append(card);
    }
  } catch (err) {
    $("ordersMessage").className="message error";
    $("ordersMessage").textContent=err.message;
    if (err.message.toLowerCase().includes("login")) showLogin();
  }
}
checkSession();
