require("dotenv").config();

const express = require("express");
const helmet = require("helmet");
const session = require("express-session");
const PgSession = require("connect-pg-simple")(session);
const { Pool } = require("pg");
const bcrypt = require("bcryptjs");
const rateLimit = require("express-rate-limit");
const crypto = require("crypto");
const path = require("path");

const app = express();
const isProduction = process.env.NODE_ENV === "production";
const port = Number(process.env.PORT || 3000);

if (!process.env.DATABASE_URL) {
  console.error("Missing DATABASE_URL. Set it in your environment.");
  process.exit(1);
}
if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32) {
  console.error("SESSION_SECRET must be set and at least 32 characters.");
  process.exit(1);
}
if (!process.env.ADMIN_USERNAME || !process.env.ADMIN_PASSWORD_HASH) {
  console.error("Set ADMIN_USERNAME and ADMIN_PASSWORD_HASH.");
  process.exit(1);
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.PGSSL === "true" ? { rejectUnauthorized: false } : undefined
});

const PACKAGES = [
  { id: "p100", diamonds: 100, price: 120 },
  { id: "p310", diamonds: 310, price: 350 },
  { id: "p520", diamonds: 520, price: 580 }
];
const METHODS = ["bkash", "nagad"];
const STATUSES = ["pending", "verified", "processing", "completed", "rejected", "refunded"];

app.set("trust proxy", 1);
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", "data:"],
      connectSrc: ["'self'"],
      objectSrc: ["'none'"],
      upgradeInsecureRequests: isProduction ? [] : null
    }
  }
}));
app.use(express.json({ limit: "20kb" }));
app.use(express.urlencoded({ extended: false, limit: "20kb" }));
app.use(session({
  store: new PgSession({ pool, createTableIfMissing: true, tableName: "user_sessions" }),
  name: "mizan.sid",
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    secure: isProduction,
    sameSite: "lax",
    maxAge: 1000 * 60 * 60 * 8
  }
}));
app.use(express.static(path.join(__dirname, "public")));

const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 8, standardHeaders: "draft-7", legacyHeaders: false });

async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS orders (
      id BIGSERIAL PRIMARY KEY,
      order_code VARCHAR(24) UNIQUE NOT NULL,
      player_uid VARCHAR(24) NOT NULL,
      package_id VARCHAR(12) NOT NULL,
      diamonds INTEGER NOT NULL,
      amount_bdt INTEGER NOT NULL,
      payment_method VARCHAR(12) NOT NULL,
      transaction_ref VARCHAR(80) NOT NULL,
      customer_note VARCHAR(250) NOT NULL DEFAULT '',
      status VARCHAR(20) NOT NULL DEFAULT 'pending',
      admin_note VARCHAR(250) NOT NULL DEFAULT '',
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);
  await pool.query("CREATE INDEX IF NOT EXISTS orders_created_at_idx ON orders(created_at DESC)");
  await pool.query("CREATE INDEX IF NOT EXISTS orders_status_idx ON orders(status)");
}

function requireAdmin(req, res, next) {
  if (req.session && req.session.isAdmin) return next();
  if (req.path.startsWith("/api/")) return res.status(401).json({ error: "Admin login required." });
  return res.redirect("/admin");
}
function cleanString(value, max) {
  return String(value ?? "").trim().slice(0, max);
}
function makeOrderCode() {
  return "MZ" + crypto.randomBytes(5).toString("hex").toUpperCase();
}

app.get("/api/packages", (req, res) => res.json(PACKAGES));

app.post("/api/orders", async (req, res) => {
  const playerUid = cleanString(req.body.playerUid, 24);
  const packageId = cleanString(req.body.packageId, 12);
  const paymentMethod = cleanString(req.body.paymentMethod, 12).toLowerCase();
  const transactionRef = cleanString(req.body.transactionRef, 80);
  const customerNote = cleanString(req.body.customerNote, 250);
  if (!/^[0-9]{6,20}$/.test(playerUid)) {
    return res.status(400).json({ error: "সঠিক Player UID দিন (৬–২০ সংখ্যার)." });
  }
  const pack = PACKAGES.find(p => p.id === packageId);
  if (!pack) return res.status(400).json({ error: "বৈধ ডায়মন্ড প্যাকেজ নির্বাচন করুন." });
  if (!METHODS.includes(paymentMethod)) return res.status(400).json({ error: "পেমেন্ট পদ্ধতি নির্বাচন করুন." });
  if (transactionRef.length < 4 || !/^[a-zA-Z0-9-]+$/.test(transactionRef)) {
    return res.status(400).json({ error: "সঠিক Transaction ID/Reference দিন." });
  }

  // The reference is only a customer claim. Admin must verify it in the official account.
  const orderCode = makeOrderCode();
  try {
    await pool.query(
      `INSERT INTO orders
       (order_code, player_uid, package_id, diamonds, amount_bdt, payment_method, transaction_ref, customer_note)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
      [orderCode, playerUid, pack.id, pack.diamonds, pack.price, paymentMethod, transactionRef, customerNote]
    );
    res.status(201).json({ orderCode, status: "pending", message: "অর্ডার জমা হয়েছে। পেমেন্ট যাচাইয়ের পর স্ট্যাটাস আপডেট হবে।" });
  } catch (err) {
    console.error("Order create failed:", err.message);
    res.status(500).json({ error: "অর্ডার জমা হয়নি। কিছুক্ষণ পরে আবার চেষ্টা করুন." });
  }
});

app.get("/api/track/:code", async (req, res) => {
  const code = cleanString(req.params.code, 24).toUpperCase();
  if (!/^MZ[A-F0-9]{10}$/.test(code)) return res.status(400).json({ error: "সঠিক অর্ডার নম্বর দিন." });
  try {
    const result = await pool.query(
      "SELECT order_code, diamonds, amount_bdt, payment_method, status, created_at, updated_at FROM orders WHERE order_code=$1",
      [code]
    );
    if (!result.rowCount) return res.status(404).json({ error: "এই অর্ডার নম্বর পাওয়া যায়নি." });
    res.json(result.rows[0]);
  } catch (err) {
    console.error("Track failed:", err.message);
    res.status(500).json({ error: "অর্ডার দেখা যাচ্ছে না। পরে চেষ্টা করুন." });
  }
});

app.get("/admin", (req, res) => res.sendFile(path.join(__dirname, "public", "admin.html")));
app.get("/api/admin/me", (req, res) => res.json({ authenticated: Boolean(req.session?.isAdmin) }));

app.post("/api/admin/login", loginLimiter, async (req, res) => {
  const username = cleanString(req.body.username, 80);
  const password = String(req.body.password ?? "");
  const userOk = username === process.env.ADMIN_USERNAME;
  let passOk = false;
  try { passOk = await bcrypt.compare(password, process.env.ADMIN_PASSWORD_HASH); } catch (_) {}
  if (!userOk || !passOk) return res.status(401).json({ error: "ইউজারনেম বা পাসওয়ার্ড সঠিক নয়." });
  req.session.regenerate(err => {
    if (err) return res.status(500).json({ error: "লগইন করা যায়নি." });
    req.session.isAdmin = true;
    req.session.save(saveErr => {
      if (saveErr) return res.status(500).json({ error: "সেশন সংরক্ষণ করা যায়নি." });
      res.json({ ok: true });
    });
  });
});

app.post("/api/admin/logout", requireAdmin, (req, res) => {
  req.session.destroy(() => {
    res.clearCookie("mizan.sid", { httpOnly: true, secure: isProduction, sameSite: "lax" });
    res.json({ ok: true });
  });
});

app.get("/api/admin/orders", requireAdmin, async (req, res) => {
  const status = cleanString(req.query.status, 20);
  const search = cleanString(req.query.search, 40);
  try {
    let sql = `SELECT order_code, player_uid, package_id, diamonds, amount_bdt, payment_method,
               transaction_ref, customer_note, status, admin_note, created_at, updated_at
               FROM orders`;
    const values = [];
    const where = [];
    if (STATUSES.includes(status)) { values.push(status); where.push(`status=$${values.length}`); }
    if (search) {
      values.push("%" + search.replace(/[%_]/g, "\\$&") + "%");
      where.push(`(order_code ILIKE $${values.length} OR player_uid ILIKE $${values.length})`);
    }
    if (where.length) sql += " WHERE " + where.join(" AND ");
    sql += " ORDER BY created_at DESC LIMIT 200";
    const result = await pool.query(sql, values);
    res.json(result.rows);
  } catch (err) {
    console.error("Admin list failed:", err.message);
    res.status(500).json({ error: "অর্ডার লোড করা যায়নি." });
  }
});

app.patch("/api/admin/orders/:code", requireAdmin, async (req, res) => {
  const code = cleanString(req.params.code, 24).toUpperCase();
  const status = cleanString(req.body.status, 20);
  const adminNote = cleanString(req.body.adminNote, 250);
  if (!STATUSES.includes(status)) return res.status(400).json({ error: "বৈধ স্ট্যাটাস নির্বাচন করুন." });
  try {
    const result = await pool.query(
      `UPDATE orders SET status=$1, admin_note=$2, updated_at=NOW()
       WHERE order_code=$3 RETURNING order_code, status, updated_at`,
      [status, adminNote, code]
    );
    if (!result.rowCount) return res.status(404).json({ error: "অর্ডার পাওয়া যায়নি." });
    res.json(result.rows[0]);
  } catch (err) {
    console.error("Admin update failed:", err.message);
    res.status(500).json({ error: "স্ট্যাটাস আপডেট করা যায়নি." });
  }
});

app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

initDb().then(() => {
  app.listen(port, () => console.log(`Mizan Gaming running on port ${port}`));
}).catch(err => {
  console.error("Database initialization failed:", err);
  process.exit(1);
});
